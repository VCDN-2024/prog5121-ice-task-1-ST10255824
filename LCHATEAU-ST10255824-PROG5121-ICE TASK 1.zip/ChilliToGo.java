package chillitogo;


import java.util.Scanner;

public class ChilliToGo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
     
         //Displays a message asking for the amount of kids meals the customer wants
        System.out.print("Enter the number of Kids meals ordered: ");
        int kidsMeals = scanner.nextInt();
        
         //Displays a message asking for the amount of adult meals the customer wants
        System.out.print("Enter the number of adult meals ordered: ");
        int adultMeals = scanner.nextInt();
        
        //This line calculates the total price of the number of adult meals that was ordered
        double adultTotal = adultMeals * 7.0;
        
        //This line calculates the total price of the number of kids meals that was ordered
        double kidsTotal = kidsMeals * 4.0;
        
        //This line adds the adult total and kids total to get the final bill
        double totalCollected = adultTotal + kidsTotal;
        
        // Display the results
        System.out.println("Total amount collected for adult meals: $" + adultTotal);
        System.out.println("Total amount collected for children's meals: $" + kidsTotal);
        System.out.println("Total amount collected for all meals: $" + totalCollected);
        
        // Close the scanner
        scanner.close();
    }
}